# THE PRIME NUMBER CHECKER PROGRAM CHECKS WHETHER AN INPUT INSERTED BY THE USER IS A PRIME NUMBER OR NOT


def prime_checker(number):
  is_prime_number = True
  for i in range(2, number - 1):
    if number % i == 0:
      is_prime_number = False
  if is_prime_number:
    print("It's a prime number")
  else:
      print("It's not a prime number")


n = int(input("Check this number: "))
prime_checker(number=n)



